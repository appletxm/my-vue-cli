import html from './template.html'

export default {
  template: html,
  data() {
    return {
      title: 'i"m help page"'
    }
  }
}
