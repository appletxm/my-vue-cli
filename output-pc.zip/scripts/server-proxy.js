var http = require('http')
var serverProxy = {
  doProxy: function (opt, request, response) {
    response.setHeader('content-type','application/json;charset=UTF-8')

    if (request.method === 'POST') {
      this.doPost(opt, request).then((result) => {
        this.createRequest(result, response, request)
      })
    } else {
      this.doGet(opt, request).then((result) => {
        this.createRequest(result, response, request)
      })
    }
  },

  createRequest: function (result, response, request) {
    var body = ''
    var req
    var querystring = require('querystring')
    // var isMultipartData = (request['headers']['content-type']).indexOf('multipart/form-data') >= 0

    req = http.request(result.options, function (res) {
      console.log('[PROXY STATUS]: ' + res.statusCode)
      console.log('[PROXY HEADERS]: ' + JSON.stringify(res.headers))

      if (request.originalUrl.indexOf('/oss/uploadImgFile') >= 0) {
        console.info('======res content-type=====', res['headers']['content-type'])
      } else {
        res.setEncoding('utf8')
      } 

      //send data to response method 1
      res.on('data', function (chunk) {
        // console.log('[PROXY BODY]: ' + chunk)
        body += chunk
      })

      //send data to response method 2
      //res.pipe(response)

      res.on('end', function () {
        // if (request.originalUrl.indexOf('/oss/uploadImgFile') >= 0) {
        //   console.info('***1******', res['headers'], body)
        // }
        console.info('[PROXY response complete]')
        response.headers = res.headers
        // if (request.originalUrl.indexOf('/oss/uploadImgFile') >= 0) {
        //   console.info('***2******', response.headers)
        // }
        response.send(body)
        response.end()
      })
    })

    req.write(result.postData + '\n')
    req.on('error', function (e) {
      console.log('problem with request: ' + e.message)
    })
    req.end(function () {
      console.info('[PROXY Request success]')
    })
  },

  doPost: function (opt, request) {
    var options
    var postData = ''
    var promise
    // var querystring = require('querystring')
    var contentType
    var isApplicationJson
    var isMultipartData

    options = {
      host: opt.host, // 这里是代理服务器       
      port: opt.port, // 这里是代理服务器端口 
      method: request.method,
      path: request.originalUrl,
      headers: {...request.headers}
    }

    contentType = request['headers']['content-type']

    isApplicationJson = contentType && contentType.indexOf('application/json') >= 0
    isMultipartData = contentType && contentType.indexOf('multipart/form-data') >= 0

    if (isMultipartData) {
      postData = new Buffer('')
    }

    promise = new Promise(function (resolve) {
      if (!contentType || isApplicationJson  || isMultipartData) {
        request.on('data', function (data) {
          if (isMultipartData){
            postData = Buffer.concat([postData, data])
          } else {
            postData += data
          }
        })

        request.on('end', function () {
          if (request.originalUrl.indexOf('/oss/uploadImgFile') >= 0) {
            console.info('[POST DATA]', postData)
          }
          // console.info('[POST DATA]', postData)
          options['headers']['Content-Type'] = isMultipartData ? contentType : 'application/json;charset=UTF-8'
          options['headers']['Content-Length'] = Buffer.byteLength(postData)
          resolve({options, postData})
        })
      } else {
        resolve({options, postData})
      }
    })

    return promise
  },

  doGet: function (opt, request) {
    console.info('[PROXY HTTP GET PARAMS]', request.params, request.query, request.body)
    var options
    var postData = ''
    var promise
    // var querystring = require('querystring')

    options = {
      host: opt.host, // 这里是代理服务器       
      port: opt.port, // 这里是代理服务器端口 
      method: request.method,
      path: request.originalUrl,
      headers: {...request.headers}
    }

    promise = new Promise(function (resolve) {
      resolve({options, postData})
    })

    return promise
  }
}

module.exports = serverProxy
