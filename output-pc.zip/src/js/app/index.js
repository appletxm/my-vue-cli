import html from './template.html'
import navigator from 'components/navigators'
import LeftMenu from 'components/left-menu'
import Bread from 'components/bread'
import { SET_USER_LOGIN_STATUS, SET_USER_INFO } from 'store/mutation-types'
import checkUserInfoCompletion from 'common/check-user-info-completion'
import { storage } from 'common/storage'
import auth from 'common/auth'

export default {
  template: html,
  data() {
    return {
      menuData: null
    }
  },
  components: {
    'navigator': navigator,
    'left-menu': LeftMenu,
    'app-bread': Bread
  },
  created() {
    let isUserLogin = auth.checkUserLogin()
    let userInfo = storage.getUserInfoFromStorage()
    let checkUserInfo

    if (isUserLogin !== true) {
      window.location.href = '/login.html'
    } else {
      checkUserInfo = checkUserInfoCompletion.isUserInfoCompleted(userInfo)
      if (checkUserInfo !== true) {
        window.location.href = checkUserInfoCompletion.doCompletionUrl
      } else {
        this.$store.commit(SET_USER_INFO, userInfo)
        this.$store.commit(SET_USER_LOGIN_STATUS, auth.checkUserLogin())
      }
    }
  },
  mounted() {}
}
