const DO_COMPLETION_URL = '/user-info-completion.html'

export default {
  doCompletionUrl: DO_COMPLETION_URL,
  isUserInfoCompleted(userInfo) {
    let checkRes = !!userInfo && !!userInfo.realName && !!userInfo.nickName

    return checkRes
  }
}
