/* global VueRouter */
let routes, router

// const Home = () => import(/* webpackChunkName: "Home" */ 'pages/home')
const UserInfo = () => import(/* webpackChunkName: "UserInfo" */ 'pages/user-info')
// const ErrorPage = () => import(/* webpackChunkName: "ErrorPage" */ 'pages/error')
const Introduction = () => import(/* webpackChunkName: "Instruction" */ 'pages/introduction')
const ChangePassword = () => import(/* webpackChunkName: "ChangePassword" */ 'pages/change-password')
const UserList = () => import(/* webpackChunkName: "UserList" */ 'pages/user-list')

function checkFromOutSideToCurrent(to) {
  if ((/http[s]*:/).test(to.fullPath)) {
    window.location.href = '/'
  }
}

routes = [
  { path: '/', component: Introduction },
  { path: '/#/', component: Introduction },
  { path: '/home', component: Introduction },
  { path: '/introduction', component: Introduction },
  { path: '/userCenter/changePassword', component: ChangePassword },
  { path: '/userCenter/userInfo', component: UserInfo },
  { path: '/userList', component: UserList },
  { path: '*', component: Introduction }
]

router = new VueRouter({routes})

router.beforeEach((to, from, next) => {
  document.body.scrollTop = 0
  next()
})

router.afterEach(function (currentPath) {
  checkFromOutSideToCurrent(currentPath)
})

export default router
