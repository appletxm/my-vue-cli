import loginModels from 'pages/login/models'

export default {
  getCurrentUserInfo(_this) {
    loginModels.getCurrentUserInfo().then((res) => {
      loginModels.getCurrentUserInfoSuccessCb(res, _this)
    }).catch((error) => {
      console.error(error)
      _this.$closeLoading()
      _this.$showMsg('warning', error.detailMessage || error.message || '登录失败')
    })
  }
}
