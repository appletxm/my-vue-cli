/* global Vue */
import '../../../css/index.less'
import html from './template.html'
import models from './models'
import uiAdapt from 'utils/mobileAdapt'
import axioDecorate from 'common/axioDecorate'
import CompletionUserinfo from 'components/completion-user-info'

uiAdapt(window, document, 750)
axioDecorate.decorate()

const userInfoCompletionPage = new Vue({
  template: html,
  data() {
    return {
      loadingObj: null,
      msgObj: null
    }
  },
  methods: {
    completionSucessCb() {
      models.getCurrentUserInfo(this)
    },

    $showMsg(type, msg) {
      this.msgObj = this.$message({
        message: msg,
        showClose: true,
        type: type,
        duration: 2000
      })
    },

    $closeMsg() {
      if (this.msgObj) {
        this.msgObj.close()
      }
    },

    $showLoading() {
      this.loadingObj = this.$loading({
        lock: true,
        spinner: 'el-icon-loading'
      })
    },

    $closeLoading() {
      if (this.loadingObj) {
        this.loadingObj.close()
      }
    }
  },
  components: {
    'completion-user-info': CompletionUserinfo
  },
  created() {},
  mounted() {}
})

userInfoCompletionPage.$mount('#app')
