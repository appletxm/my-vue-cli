import html from './template.html'

export default {
  template: html,

  data() {
    return {}
  },

  computed: {},

  methods: {},

  components: {},

  created() {},

  mounted() {}
}
