import html from './template.html'
import CompletionUserinfo from 'components/completion-user-info'

export default {
  template: html,
  data() {
    return {}
  },
  created() {},
  mounted() {},
  methods: {},
  components: {
    'completion-user-info': CompletionUserinfo
  }
}
